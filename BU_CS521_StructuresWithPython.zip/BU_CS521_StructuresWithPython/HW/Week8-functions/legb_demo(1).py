
var = "global"

def outter():

    def inner1():
        var = "local of inner1"
        print("----inner1 after setting var: ", var)

    def inner2():
        nonlocal var
        var = "set in inner2"
        print("----inner2: ", var)

    def inner3():
        global var
        var = "set in inner3"
        print("----inner3: ", var)

    var = "enclosed in outter"
    print("--outter beginning: ", var)
    inner1()
    print("--outter after calling inner1: ", var)
    inner2()
    print("--outter after calling inner2: ", var)
    inner3()
    print("--outter after calling inner3: ", var)

def main():
    print("main beginning: ", var)
    outter()
    print("main after calling outter: ", var)
    print("module name:", __name__)
    

if __name__ == "__main__":
    main()

