
def add2list(elem, lst = []):
    if elem not in lst:
        lst.append(elem)

    return lst

list1 = add2list(30, [10, 20])
print("list1:", list1)

list2 = add2list(51)
print("list2:", list2)

list3 = add2list(61)
print("list3:", list3)

