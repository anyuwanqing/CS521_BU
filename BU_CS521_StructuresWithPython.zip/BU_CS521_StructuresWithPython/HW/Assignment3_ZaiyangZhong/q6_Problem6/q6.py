
from collections import Counter

"""Problem 6"""
import os.path


res = Counter()
total = 0


def findFrequency(lists):
    for list in lists:
        for word in list:
            for char in word:
                if char.isalpha() == True:
            # using collections.Counter() to get
            # count the lower case of alphabet
                    res.update(Counter(char.lower()))

    print ("Count of all characters is :\n "+  str(res))


    # sort by alphabet a - z
    alpha_list = sorted(res.items())


    return alpha_list








def main():

    list_of_lists = []
    fileName = "sample_input_charles_dickens.txt"
    # import random
    if os.path.isfile(fileName):
        print("ram_integer exists")
        print("reading it....")

        with open(fileName, "r") as f:
            for line in f:
                inner_list = [elt.strip() for elt in line.split(' ')]
                list_of_lists.append(inner_list)

        list = findFrequency(list_of_lists)


        print(list)

        total = 0

        # calculate total, and frequency for each
        for each in list:
            total += each[1]
        print("total counts of letters: ", total)


        with open("results_q6_ZaiyangZhong.txt", "w") as f:
            f.write("Char  Freq   %total \n")
            print("Char  Freq   %total \n")
            for each in list:
                l = str(each[0])
                freq = str(each[1])
                perc = str(each[1]/total*100)
                line =""
                line = l + " " + freq + " " + perc
                f.write(line)
                print(line)
                f.write("\n")

        f.close()





main()





