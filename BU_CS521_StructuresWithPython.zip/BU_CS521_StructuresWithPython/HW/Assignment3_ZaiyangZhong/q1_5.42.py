
""" 5.42 (Monte Carlo simulation)
 A square is divided into four smaller regions
 as shown in
 (a). If you throw a dart into
 the square one million times, what is the
 probability for the dart to fall into
 an odd-numbered region? """

import random

NUMBER_OF_GRAILS = 100000 # throw dat a million time

num_hits = 0;

num_hits_2 = 0;

for i in range(NUMBER_OF_GRAILS):
    x = random.random() * 2.0 -1;
    y = random.random() * 2.0 -1;

    # region 1 is everything x < 0
    if x < 0:
        num_hits +=1
        # region 3 is everything not 2 in upper right triangle
    elif not (x > 1 or x < 0 or y > 1 or y < 0):
        m = -1 #slope for triangle
        x2 = x - y*m
        if x2 <= 1:
            num_hits +=1

print("Probability for date to fall in odd number region, which is 1 and 3, is: ",
    num_hits/NUMBER_OF_GRAILS)

# this is for (b)
for i in range(NUMBER_OF_GRAILS):
    x = random.random() * 2.0 -1;
    y = random.random() * 2.0 -1;

    # region 1 is everything x < 0
    if x < 0 and y<0:
            num_hits_2 +=1
        # region 3 is everything not 2 in upper right triangle
    elif not (x > 1 or x < 0 or y > 1 or y < 0):
        m = -1 #slope for triangle
        x2 = x - y*m
        if x2 <= 1:
            num_hits_2 +=1

print("Probability for date to fall in odd number region, which is 1 and 3, is: ",
      num_hits_2/NUMBER_OF_GRAILS)


