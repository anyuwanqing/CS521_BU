

"""13.4 (Write/read data)
Write a program that writes 100 integers
created randomly into a file.
Integers are separated by a space in the file.
Read the data back from the file
and display the sorted data.
Your program should prompt the user to enter
a file- name.
If the file already exists, do not overwrite it.
Here is a sample run:
"""

import os.path
# import random
if os.path.isfile("ram_integer.txt"):
    print("ram_integer exists")
    print("reading it....")

    with open("ram_integer.txt", "r") as f:
        print(f.read())
    f.close()


else:
    filename = "ram_integer.txt"

    # create a new one
    with open(filename, "w") as f:
        print("The 100 random integers written are: ")
    for i in range(100):
        line = str(random.randint(1,100))
    f.write(line)
    f.write(" ")

    # reading
    with open(filename, "r") as f:
        print(f.read())
    f.close()


