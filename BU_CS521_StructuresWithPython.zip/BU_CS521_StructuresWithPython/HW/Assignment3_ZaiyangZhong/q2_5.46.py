

""" 5.46
(Statistics: compute mean and standard deviation)
In business applications, you are often
asked to compute the mean and standard deviation
 of data. The mean is simply the average of
 the numbers. The standard deviation is a statistic that
  tells you how tightly all the various data are clustered
  around the mean in a set of data. For example, what is
   the average age of the students in a class? How close are
   the ages? If all the students are the same age, the deviation
   is 0. Write a program that prompts the user to enter ten numbers,
   and displays the mean and standard devia- tions of these numbers
   using the following formula:
   """
import math
num_arr = list(map(int, input("Enter multiple numbers: ").split()))
print("List ofnumbers: ", num_arr, " used to find mean and standard deviation")

size = len(num_arr)
print(size)

total = 0
s_d = 0

for element in num_arr:
    total += element

mean = total / size
print("MEAN  of these number: ", mean)


def variance(data):
    n = size - 1
    s = 0
    for element in num_arr:
        calculation = (element - mean) ** 2
        s = s + calculation
    return s/n

def stdev(data):
    var = variance(data)
    std_dev = math.sqrt(var)
    return std_dev

print("STANDARD DEVIATION is: ", stdev(num_arr))

