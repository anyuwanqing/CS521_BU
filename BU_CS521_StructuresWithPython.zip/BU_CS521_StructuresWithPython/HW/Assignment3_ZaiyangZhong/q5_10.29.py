
"""10.29 (Game: hangman)
Write a hangman game that randomly generates a word
and prompts the user to guess one letter at a time,
as shown in the sample run. Each letter in the word is
displayed as an asterisk. When the user makes a correct guess,
the actual letter is then displayed. When the user
finishes a word, dis- play the number of misses and ask
 the user whether to continue playing. Create a list to store
 the words, as follows:
"""

import random

words_arr = ["that","good", "apple"]

def current_guess(word, guesses):
    ast_word = ""
    for char in word:
        if char in guesses:
            ast_word += char
        else:
            ast_word += "*"
    return ast_word


def play():
    play_again = True;
    first_round = True;

    while play_again:
        word = random.choice(words_arr)
        ast_word = ""
        for i in range(len(word)):
            ast_word += "*"
        print(ast_word)

        guesses = []

        guess_wrong = 0


        if play_again: # starting
            # while didn't guess the full word
            while "*" in current_guess(word, guesses):
                guess = input("Enter a letter in word " + current_guess(word,guesses) + ":")
                guesses.append(guess)
                if guess in guesses and guess in word:
                    print(guess + " is in the word")
                elif guess not in word:
                    print(guess + " is not in the word.")
                    guess_wrong += 1
                else:
                    guesses.append(guess)

            print("Congrat! You guess the word successfully")
            print("the word is " + word + ". You missed " + str(guess_wrong) + " times.")
            again = input("Do you want to play again? y or n ")
            if again == "n":
                play_again = False


play()


