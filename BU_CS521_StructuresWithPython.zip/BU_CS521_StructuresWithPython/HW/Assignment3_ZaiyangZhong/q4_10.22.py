

"""10.22"""
""""(Simulation: coupon collector’s problem) 
Coupon Collector is a classic statistics problem 
with many practical applications. 
The problem is to pick objects from a set of objects 
repeatedly and find out how many picks are needed 
for all the objects to be picked at least once. 
A variation of the problem is to pick cards
 from a shuffled deck of 52 cards repeatedly and find out 
 how many picks are needed before you see one of each suit. 
 Assume a picked card is placed back in the deck before picking another. 
 Write a program to simulate the number of picks needed to
  get four cards, one from each suit and display the four cards 
  picked (it is possi- ble a card may be picked twice). 
  Here is a sample run of the program:
"""
import random

DECK_SIZE = 52
suits = ["Clubs", "Diamonds", "Hearts", "Spades"]
ranks = ["Ace", "2", "3", "4", "5", "6", "7", "8", "9",
             "10", "Jack", "Queen", "King"]

# default pick
num_picks = 0

deck = [x for x in range(1, DECK_SIZE)] # array of 1 ~ 52
print(deck)

# suit found is a boolean array representing 4 suits
suit_found = [False, False, False, False] ## club, diamound, hearts, and spades


# while not founding all suit == True
while not (suit_found[0] == True and suit_found[1] == True and suit_found[2] == True and suit_found[3] == True):
    num_picks += 1
    card_index = random.randint(1, DECK_SIZE) # 0 ~ 51
    print("card index " + str(card_index))
    suit = suits[card_index // 13 -1] # 0 1 2 3
    rank = ranks[card_index % 13]
    if suit == "Clubs":
        suit_found[0] = True
        print("Card num (1 ~ 52) #", card_index, "is ", rank, " of ", suit )
    elif suit == "Diamonds":
        suit_found[1] = True
        print("Card num (1 ~ 52) #", card_index, "is ", rank, " of ", suit )
    elif suit == "Hearts":
        suit_found[2] = True
        print("Card num (1 ~ 52) #", card_index, "is ", rank, " of ", suit )
    elif suit == "Spades":
        suit_found[3] = True
        print("Card num (1 ~ 52) #", card_index, "is ", rank, " of ", suit )

print("\nNumber of picks: ", num_picks)

