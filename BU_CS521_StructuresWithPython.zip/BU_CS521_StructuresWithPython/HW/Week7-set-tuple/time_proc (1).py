import datetime

# create a datetime object
t = datetime.datetime(2021, 3, 8, 18, 0, 5)
print(t)

# Get current time
t = datetime.datetime.now()
type(t)
print(t) # in iso format

# convert a datetime object to a formatted string
print(t.strftime("%m/%d/%Y %I:%M:%S %p"))

# parse a format string into a datetime object
start = "03/06/2021 20:08:22"
end   = "03/08/2021 18:15:33"

s_dt = datetime.datetime.strptime(start, "%m/%d/%Y %H:%M:%S")
e_dt = datetime.datetime.strptime(end, "%m/%d/%Y %H:%M:%S")

# time delta
t_delta = e_dt - s_dt
minute_diff = t_delta.days * 24 * 60 + t_delta.seconds // 60

# naive parsing
dt_lst = start.split()
d_lst = dt_lst[0].split("/")
t_lst = dt_lst[1].split(":")

m = int(d_lst[0])
d = int(d_lst[1])
y = int(d_lst[2])
hr = int(t_lst[0])
mi = int(t_lst[1])
sc = int(t_lst[2])
s_dt = datetime.datetime(y, m, d, hr, mi, sc)

dttpl = (y, m, d, hr, mi, sc)
s_dt = datetime.datetime(*dttpl)

