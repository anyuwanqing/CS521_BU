INPUT_FILE_NAME = "/Users/alvin/Lu/BU/CS521A1/sample_input_charles_dickens.txt"
OUTPUT_FILE_NAME = "/Users/alvin/Lu/BU/CS521A1/sample_output.txt"
TEMPLATE_STR = "{0}\t{1:3d}\t{2:6.2%}\n"

# each element of the list corresponds to the counter for a letter
counters = [0] * 26

# read the file and process one line at a time
with open(INPUT_FILE_NAME, "r") as inputfile:
    for line in inputfile:
        for c in line:
            i = ord(c.upper()) - ord("A")
            if i >= 0 and i <= 25:
                counters[i] += 1

total_count = sum(counters)

# write output to a file
with open(OUTPUT_FILE_NAME, "w") as outputfile:
    # write out header line
    outputfile.write("Char\tFreq\t%total\n")

    for i in range(26):
        outputfile.write(TEMPLATE_STR.format(chr(i+ord("A")), counters[i], counters[i] / total_count))

