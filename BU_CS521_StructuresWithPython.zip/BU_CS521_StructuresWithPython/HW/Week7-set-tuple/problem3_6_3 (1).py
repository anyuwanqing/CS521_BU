INPUT_FILE_NAME = "sample_input_charles_dickens.txt"
TEMPLATE_STR = "{0}\t{1:3d}\t{2:6.2%}\n"

counters = {}

# read the file and process one line at a time
with open(INPUT_FILE_NAME, "r") as inputfile:
    for line in inputfile:
        for word in line.split():
            if word in counters:
                counters[word] += 1
            else:
                counters[word] = 1

for word in counters:
    print(word, " : ", counters[word])

