import csv

m_list = []

with open("movie.csv") as m_file:
    
    m_reader = csv.DictReader(m_file)
    
    for row in m_reader:
        m_list.append((row["Release"], row["Title"]))

m_list.sort()
for m in m_list:
    print(m[0], m[1], sep = "\t")

