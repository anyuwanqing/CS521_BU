# Assignment1 _ Zaiyang Zhong
#Python 3.10

#2.21
"""(Financial application: compound value)"""
"""Suppose you save $100 each month into a savings account 
with an annual interest rate of 5%. Therefore, 
the monthly interest rate is 0.05/12 = 0.00417. 
After the first month, the value in the account becomes
            100 * (1 + 0.00417) = 100.417
After the second month, the value in the account becomes
          (100 + 100.417) * (1 + 0.00417) = 201.252
After the third month, the value in the account becomes
          (100 + 201.252) * (1 + 0.00417) = 302.507
and so on.
Write a program that prompts the user to enter a monthly 
saving amount and displays the account value after the sixth month. 
"""

def compound_value_with_5percent_annual_interest_after_six_month(dollars):

    i=0
    acc_value = 0
    while i<6: # loop 6 times
        acc_value = (dollars + acc_value) * (1 + 0.05/12)
        i += 1

    # handle decimals
    acc_value = str(round(acc_value, 2))
    return acc_value

saving = eval(input("Enter the monthly saving amount:"))
print("After six month, the account value is: ", compound_value_with_5percent_annual_interest_after_six_month(saving))

