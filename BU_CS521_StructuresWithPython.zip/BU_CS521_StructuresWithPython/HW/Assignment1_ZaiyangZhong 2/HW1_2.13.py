# Assignment1 _ Zaiyang Zhong
#Python 3.10

#2.13
"""(Split digits) """
"""Write a program that prompts the user to enter 
a four-digit integer and 
displays the number in reverse order. """

def split_digits(n):

    list = [0,0,0,0]

    if (len(str(n)) != 4):
        print("Error!!! Your input is NOT a four-digit integer")
    else:
        i=0 # index
        while n:
            digit = n % 10
            list[i] = digit # store the digit into list, for four times
            i += 1

            # now, handle the rest
            n = n // 10


    return list


four_digits_num = eval(input("Enter a four-digit integer:"))
print(split_digits(four_digits_num)[0], "\n",split_digits(four_digits_num)[1], "\n", \
      split_digits(four_digits_num)[2], "\n",split_digits(four_digits_num)[3])

