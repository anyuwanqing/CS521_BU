# Assignment1 _ Zaiyang Zhong
#Python 3.10

#2.7
"""(Find the number of years and days) """
"""Write a program that prompts the user to enter 
the minutes (e.g., 1 billion), and displays 
the number of years and days for the minutes. 
For simplicity, assume a year has 365 days. """

def mins_to_years_and_days(n):

    years = n/60/24/365
    new_years = int(years) # to integer

    days = n/60/24 - new_years*365
    new_days = int(days) # to integer

    years_and_days = [new_years, new_days]

    return years_and_days

mins = eval(input("Enter the number of minutes:"))
print(mins, " minutes is approximately ", mins_to_years_and_days(mins)[0], " and ", mins_to_years_and_days(mins)[1], " days.")



