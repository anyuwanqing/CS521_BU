# Assignment1 _ Zaiyang Zhong
# Python 3.10


# Programming Exercises

# Page 86 - 87): 3.3, 3.9;

# (Page 125 - 130): 4.21, 4.28, 4.33, 4.34



# 3.3
""" (Geography: estimate areas) Find the GPS locations for Atlanta, Georgia;
 Orlando, Florida; Savannah, Georgia;
 and Charlotte, North Carolina from www.gps-data-team.com/map/
 and compute the estimated area enclosed by these four cities.
  (Hint: Use the formula in Programming Exercise 3.2
  to compute the distance between two cities.
  Divide the polygon into two triangles and use the formula
  in Programming Exercise 2.14 to compute the area of a triangle.)
"""

"""
formula 1:
d = radius * arc cos(sin(x1) * sin(x2) + cos(x1) * cos(x2) * cos(y1 - y2))
"""

"""
formula 2 for triangle:
s = (side1 + side2 + side3)/2
area = sqrt(s(s - side1) * (s - side2) * (s- side3))
"""

import math

# city coordinates [latitude, longitude]
atlanta = [33.7490, -84.3880]
orlando = [28.5384, -81.3789]
savannah = [32.0809, -81.0912]
charlotte = [35.2271, -80.8431]

# all coordinates in x,y
x1 = math.radians(atlanta[0])
y1 = math.radians(atlanta[1])

x2 = math.radians(orlando[0])
y2 = math.radians(orlando[1])

x3 = math.radians(savannah[0])
y3 = math.radians(savannah[1])

x4 = math.radians(charlotte[0])
y4 = math.radians(charlotte[1])



EARTH_RADIUS = 6371.01 # which is fixed, in KM

# compute sides
side1 = EARTH_RADIUS * math.acos(math.sin(x1) * math.sin(x2) + math.cos(x1) * math.cos(x2) * math.cos(y1 - y2))
side2 = EARTH_RADIUS * math.acos(math.sin(x2) * math.sin(x3) + math.cos(x2) * math.cos(x3) * math.cos(y2 - y3))
side3 = EARTH_RADIUS * math.acos(math.sin(x3) * math.sin(x1) + math.cos(x3) * math.cos(x1) * math.cos(y3 - y1))
side4 = EARTH_RADIUS * math.acos(math.sin(x4) * math.sin(x1) + math.cos(x4) * math.cos(x1) * math.cos(y4 - y1))
side5 = EARTH_RADIUS * math.acos(math.sin(x4) * math.sin(x3) + math.cos(x4) * math.cos(x3) * math.cos(y3 - y1))
# compute s1
s1 = (side1 + side2 + side3) / 2
# Compute the area
area1 = math.sqrt(s1 * (s1 - side1) * (s1 - side2) * (s1 - side3))


# Compute s2
s2 = (side3 + side4 + side5) / 2
# Compute the area
area2 = math.sqrt(s2 * (s2 - side3) * (s2 - side4) * (s2 - side5))

area = area1 + area2  # the polygon hole area

# Display the result
print("The estimated area enclosed by these four cities --Atlanta, Orlando, Savannah, Charlotte-- is:", area, " square km")





#3.9
"""(Financial application: payroll) 
Write a program that reads the following information and prints a payroll statement:
Employee’s name (e.g., Smith)
Number of hours worked in a week (e.g., 10) Hourly pay rate (e.g., 9.75)
Federal tax withholding rate (e.g., 20%) State tax withholding rate (e.g., 9%)"""


class Employee:

    def __init__(self, name, hrs_week, hrs_pay):

        self.name = name
        self.hrs_week = hrs_week
        self.hrs_pay = hrs_pay

        self.week_pay = self.hrs_week * self.hrs_pay
        self.deduction_federal = self.week_pay * FEDERAL_TAX_RATE
        self.deduction_state = self.week_pay * STATE_TAX_RATE
        self.deduction = self.deduction_federal + self.deduction_state

        self.net_pay = self.week_pay - self.deduction


new_name = input("Enter employee's name:")
new_hrs_week = eval(input("Enter number of hours worked in a week:"))
new_hrs_pay = eval(input("Enter hourly pay rate:"))
FEDERAL_TAX_RATE = eval(input("Enter federal tax withholding rate (eg. 0.2):"))
STATE_TAX_RATE = eval(input("Enter state tax withholding rate (eg. 0.09:"))

Employee1 = Employee(new_name, new_hrs_week, new_hrs_pay)

print("Emloyee's name: ", new_name)
print("Hours worked: ", new_hrs_week)
print("Pay Rate: ", new_hrs_pay)
print("Gross Pay: " , Employee1.week_pay)
print("Deductions:\n", "   Federal Withholding (", FEDERAL_TAX_RATE, 100*FEDERAL_TAX_RATE, "%): ", round(Employee1.deduction_federal, 2))
print("   State Withholding (", STATE_TAX_RATE, 100*STATE_TAX_RATE, "%): ", round(Employee1.deduction_state,2))
print("   Total Deduction: ", round(Employee1.deduction,2))
print("Net Pay: ", round(Employee1.net_pay,2))





#4.21

#import math

"""
(Science: day of the week) Zeller’s congruence is an 
algorithm developed by Christian Zeller 
to calculate the day of the week. The formula is
h = ¢q + j26(m + 1)k + k + jkk + jjk + 5j≤%7 10 44
where

■ h is the day of the week (0: Saturday, 1: Sunday, 2: Monday, 3: Tuesday, 4: Wednesday, 5: Thursday, 6: Friday).
■ q is the day of the month.
■ m is the month (3:March,4:April,...,12:December).January and February are
counted as months 13 and 14 of the previous year.
year
■ j is the century (i.e.,j 100 k).
■ k is the year of the century(i.e.,year%100).
Write a program that prompts the user to enter a year, month, and day of the month, and then it displays the name of the day of the week. Here are some sam- ple runs:
"""


input_year = eval(input("Enter year:"))
input_month = eval(input("Enter month: 1-12:"))
input_day = eval(input("Enter the day of the month: 1-31:"))


q = input_day
# handle month
if input_month > 2:
    m = input_month
    j = math.floor(input_year // 100) #2022/100 = 202.2  -> 202
    k = input_year % 100


else:
    # counted as previous year, so year much be 1 less
    input_year -= 1

    m = input_month + 12
    j = math.floor(input_year // 100) #2022/100 = 202.2  -> 202
    k = input_year % 100


# use formula
h = (q + math.floor((26 * (m + 1)) / 10) + k + math.floor(k / 4)
     + math.floor(j / 4) + 5 * j) % 7

return_day = {
    0 : "Saturday",
    1 : "Sunday",
    2 : "Monday",
    3 : "Tuesday",
    4 : "Wednesday",
    5 : "Thursday",
    6 : "Friday"
}

day = return_day[h]

print("Day of the week is: ", day)




# 4.28

"""(Geometry: two rectangles)
 Write a program that prompts the user to enter
  the center x-, y-coordinates, width, and 
  height of two rectangles and determines whether 
  the second rectangle is inside the first or overlaps with the first, 
  as shown in Figure 4.10. Test your program to cover all cases.
  """

#import math
rec_x1, rec_y1, rec_w1, rec_h1 = eval(input("Enter r1's center x-, y-coordinates, width and height:"))
rec_x2, rec_y2, rec_w2, rec_h2 = eval(input("Enter r2's center x-, y-coordinates, width and height:"))


#calculate the points of the rectangle
right1 = rec_x1 + rec_w1/2
left1 = rec_x1 - rec_w1/2
top1 = rec_x1 + rec_h1/2
bottom1 = rec_x1 - rec_h1/2

right2 = rec_x2 + rec_w2/2
left2 = rec_x2 - rec_w2/2
top2 = rec_x2 + rec_h2/2
bottom2 = rec_x2 - rec_h2/2


if right2 <= right1 and left2 >= left1 and top2 <= top1 and bottom2 >= bottom1:
    print("r2 is inside r1")
elif right2 <= left1 or left2 >= right1 or bottom2 >= top1 or top2 <=bottom1:
    print("r2 does not overlap r1")
else:
    print("r2 overlaps r1")





#4.33
"""
(Decimal to hex) Write a program that prompts the user to enter 
an integer between 0 and 15 and displays its corresponding
 hex number. Here are some sam- ple runs:
"""

decimal_value = eval(input("Enter a decimal value (0 to 15):  "))

decimal_hex = {
    10: "A",
    11: "B",
    12: "C",
    13: "D",
    14: "E",
    15: "F",
}

if decimal_value > 15 or decimal_value < 0:
    print("Invalid input")
elif decimal_value < 10:
    print("the hex calue is ", decimal_value)
else:
    print(decimal_hex[decimal_value])



# 4.34

"""(Hex to decimal) Write a program that prompts the user 
to enter a hex character and displays its 
corresponding decimal integer. 
Here are some sample runs
"""

hex_value = input("Enter a hex value (0 to 10 and A to F):  ")


if len(hex_value) != 1 or ord(hex_value) > ord('F') and ord(hex_value) < ord('a') or ord(hex_value) > ord('f'):
    print("Invalid input")
else:
    if hex_value == 'a' or hex_value == 'A':
        print("10")
    elif hex_value == 'b' or hex_value == 'B':
        print("11")
    elif hex_value == 'c' or hex_value == 'C':
        print("12")
    elif hex_value == 'd' or hex_value == 'D':
        print("13")
    elif hex_value == 'e' or hex_value == 'E':
        print("14")
    elif hex_value == 'f' or hex_value == 'F':
        print("15")
    else:
        print(hex_value)

