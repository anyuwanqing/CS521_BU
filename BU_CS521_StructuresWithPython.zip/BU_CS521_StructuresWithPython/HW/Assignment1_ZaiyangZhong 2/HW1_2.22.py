# Assignment1 _ Zaiyang Zhong
#Python 3.10

#2.22
"""Exercise 1.11
(Population projection) The US Census Bureau projects population based on the following assumptions:
    One birth every 7 seconds
    One death every 13 seconds
    One new immigrant every 45 seconds
Write a program to display the population
for each of the next five years.
Assume the current population is 312032486
and one year has 365 days. Hint: in Python,
you can use integer division operator // to perform division.
The result is an integer. For example,5 // 4 is 1 (not 1.25) and 10 // 4 is 2 (not 2.5)."""

"""Exercise 2.22 (modified version from 1.11)"""

"""(Population projection) """
"""Rewrite Exercise 1.11 to prompt the user to 
enter the number of years and displays the population 
after that many years.  
    current population: 312032486.
"""

def population_after_given_years(years):

    current_population = 312032486
    second_in_a_year = 365*24*60*60
    second_in_given_years  = years * second_in_a_year
    tot_death = second_in_given_years // 13
    tot_birth = second_in_given_years // 7
    tot_immigrants = second_in_given_years // 45

    current_population = current_population + tot_birth + tot_immigrants - tot_death

    return current_population

years = eval(input("Enter the number of years:"))
print("The population in five years will be: ", population_after_given_years(years))

