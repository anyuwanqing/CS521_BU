# Assignment1 _ Zaiyang Zhong
#Python 3.10



#2.14
"""(Geometry: area of a triangle) """
"""Write a program that prompts the user to 
enter the three points (x1, y1), (x2, y2), and (x3, y3) 
of a triangle and displays its area. 
The formula for computing the area of a triangle is
s = (side1 + side2 + side3)/2
area = 2s(s - side1)(s - side2)(s - side3) """

def area_triangle_with_3_points(x1, y1, x2, y2, x3, y3):
    area = abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)  ) / 2.0

    # handle decimal -> convert to one decimal
    area = str(round(area, 1))

    return area


points = eval(input("Enter three points in this format (split by comma) (e.g. x1, y1, x2, y2, x3, y3)  :" ))
print("Area of the triangle formed by this three points is:", area_triangle_with_3_points(points[0], points[1], points[2], points[3], points[4], points[5]))



