"""(Page 428 - 430): 12.2, 12.3
(Page 523 - 525): 15.1, 15.3, 15.23
"""

"""(The Location class) Design a class named Location
 for locating a maximal value and its location in a 
 two-dimensional list. The class contains the public data 
 fields row, column, and maxValue that store the maximal 
 value and its indexes in a two-dimensional list, with 
 row and column as int types and maxValue as a float type.
Write the following method that returns the location of 
the largest element in a two-dimensional list.
def Location locateLargest(a):
The return value is an instance of Location.
 Write a test program that prompts the user to enter 
 a two-dimensional list and displays the location 
 of the largest ele- ment in the list. 
 Here is a sample run:
"""



# import Math

class Location:
    # constructor
    def __init__(self,row=0,column=0,maxValue=0):
        self.row = row
        self.column = column
        self.maxValue = maxValue

def __str__(self):
    return "(Row : "+str(self.row)+" Column : "+str(self.column)+" Value : "+str(self.maxValue)+")";


# return the largest and store it to Location
def locateLargest(array):
    r=0
    c=0
    for i in range(len(array)):
        for j in range(len(array[0])):
            if array[i][j]>array[r][c]:
                r = i # the max row position
                c = j # max col position
    return Location(r,c,array[r][c])

print('Enter num of rows and columns (2, 3): ',end='');
data = input().strip().split(',')
rows = int(data[0].strip())
cols = int(data[1].strip())

twoD = list()
for i in range(rows):
    print('Enter row '+str(i)+':  (1 2 3)',end='')
    data = input().strip().split()
    l = []
    for x in data:
        l.append(float(x))
    twoD.append(l) # append to 2d array

loc = locateLargest(twoD)
print('location of the largest element is at ('+str(loc.row)+', '+str(loc.column)+')')
print('max is ' + str(loc.maxValue))