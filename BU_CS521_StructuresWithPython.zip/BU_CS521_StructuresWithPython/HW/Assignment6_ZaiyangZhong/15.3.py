"""(Page 428 - 430): 12.2, 12.3
(Page 523 - 525): 15.1, 15.3, 15.23
"""

"""15.3
(Compute greatest common divisor using recursion) 
The gcd(m, n) can also be defined recursively as follows:
■ Ifm % nis0,gcd(m, n)isn.
■ Otherwise,gcd(m, n)isgcd(n, m % n).
Write a recursive function to find the GCD. 
Write a test program that prompts the user to 
enter two integers and displays their GCD.

"""

def gcd(m,n):
    if (n == 0):
        return m
    else:
        return gcd(n, m%n)
# keep finding until n is zero
def main():
    print('test gcd')
    print("gcd of ", 32, " and ", 64, " is ", gcd(32,64))

main()