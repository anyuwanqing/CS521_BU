"""(Page 428 - 430): 12.2, 12.3
(Page 523 - 525): 15.1, 15.3, 15.23
"""

"""12.3

(Game: ATM machine) Use the Account class created 
in Exercise 7.3 to simulate an ATM machine. 
Create ten accounts in a list with the ids 0, 1, ..., 9,
 and an ini- tial balance of $100. The system prompts the user to
  enter an id. If the id is entered incorrectly, ask the user to
   enter a correct id. Once an id is accepted, the main menu is displayed 
   as shown in the sample run. You can enter a choice of 1 
   for viewing the current balance, 2 for withdrawing money, 3 for
    depositing money, and 4 for exiting the main menu. Once you exit, 
    the system will prompt for an id again. So, once the system starts, 
    it won’t stop.
"""




"""
(The Account class) Design a class named Account that contains:
    ■ A private int data field named id for the account.
    ■ A private float data field named balance for the account.
    ■ A private float data field named annualInterestRate that stores the current
interest rate.
■ A constructor that creates an account
 with the specified id (default 0), initial
balance (default 100), and annual interest rate (default 0).
■ The accessor and mutator methods for id, 
balance, and annualInterestRate.
■ A method named getMonthlyInterestRate() 
that returns the monthly
interest rate.
■ A method named getMonthlyInterest() that
 returns the monthly interest.
■ A method named withdraw that withdraws a 
specified amount from the
account.
■ A method named deposit that deposits a 
specified amount to the account.
Draw the UML diagram for the class, and 
then implement the class. (Hint: The method
 getMonthlyInterest() is to return the 
 monthly interest amount, not the interest rate. 
 Use this formula to calculate the monthly interest:
  balance * monthlyInterestRate. 
  monthlyInterestRate is annualInterestRate / 12. 
  Note that annualInterestRate is a percent (like 4.5%). 
  You need to divide it by 100.)
Write a test program that creates an 
Account object with an account id of 1122, 
a balance of $20,000, and an annual interest 
rate of 4.5%. Use the withdraw method to 
withdraw $2,500, use the deposit method to 
deposit $3,000, and print the id, balance, 
monthly interest rate, and monthly interest.

"""


class lowBalanceException:
    """happens when withdraw but not enough balance"""
    pass

# import Math
class Account:
    def __init__(self, id=0, balance=0.0, annualInterestRate=0.25):
        self.__id = id
        self.__balance = balance
        self.__annualInterestRate = annualInterestRate

    # getters
    def getId(self):
        return self.__id

    def getBalance(self):
        return self.__balance

    def getAnnualInterestRate(self):
        return self.__annualInterestRate

    # setters
    def setId(self, id):
        self.__id = int(id)

    def setBalance(self, balance):
        self.__balance = float(balance)

    def setAnnualInterestRate(self, annualInterestRate):
        self.__annualInterestRate = float(annualInterestRate)

    # functions
    def getMonthlyInterestRate(self):
        return self.__annualInterestRate / 12

    def getMonthlyInterest(self):
        return self.getMonthlyInterestRate() * self.getBalance()

    def withdraw(self, money):
        self.setBalance(self.getBalance() - money)

    def deposit(self, money):
        self.setBalance(self.getBalance() + money)

def createTenAccount():

    acc = []

    account1 = Account()
    account1.setId(1)
    account1.setBalance(20000)

    account2 = Account()
    account2.setId(2)
    account2.setBalance(20000)

    account3 = Account()
    account3.setId(3)
    account3.setBalance(20000)

    account4 = Account()
    account4.setId(4)
    account4.setBalance(20000)

    account5 = Account()
    account5.setId(5)
    account5.setBalance(20000)

    account6 = Account()
    account6.setId(6)
    account6.setBalance(20000)

    account7 = Account()
    account7.setId(7)
    account7.setBalance(20000)

    account8 = Account()
    account8.setId(8)
    account8.setBalance(20000)

    account9 = Account()
    account9.setId(9)
    account9.setBalance(20000)

    account10 = Account()
    account10.setId(10)
    account10.setBalance(20000)

    acc.append(account1)
    acc.append(account2)
    acc.append(account3)
    acc.append(account4)
    acc.append(account5)
    acc.append(account6)
    acc.append(account7)
    acc.append(account8)
    acc.append(account9)
    acc.append(account10)

    return acc

def main(acc):

    i = 0
    while i == 0:
        print('Enter an account id: ')
        index = int(input())

        sameAccount = True

        while sameAccount:

            print("Main Menu\n1: check balance\n2: withdraw\n3: deposit\n4:exit")
            choice = int(input("Enter a choice:"))

            if choice == 1:
                print(acc[index-1].getBalance())

            elif choice == 2:
                print("enter amount to withdraw:")
                money = int(input())
                acc[index-1].withdraw(money)
                if(acc[index-1].getBalance() < 0):
                    raise lowBalanceException("Balance is lower than zero!!")

            elif choice == 3:
                print("enter amount to deposit:")
                money = int(input())
                acc[index-1].deposit(money)

            elif choice == 4:
                sameAccount = False



def testException(acc):
    i = 0
    while i == 0:
        print('(Test) Enter an account id:  1')
        index = 1

        sameAccount = True

        while sameAccount:

            print("Main Menu\n1: check balance\n2: withdraw\n3: deposit\n4:exit")
            print("(Test) Enter a choice: 2")

            choice = 2
            if choice == 1:
                print(acc[index-1].getBalance())

            elif choice == 2:
                print("(Test) enter amount to withdraw: 9999999")
                money = 9999999
                acc[index-1].withdraw(money)
                if(acc[index-1].getBalance() < 0):
                    raise lowBalanceException("Balance is lower than zero!!")

            elif choice == 3:
                print("enter amount to deposit:")
                money = int(input())
                acc[index-1].deposit(money)

            elif choice == 4:
                sameAccount = False



main(createTenAccount())

"""TO TEST, comment out main() above and uncomment the next line"""
#testException(createTenAccount())