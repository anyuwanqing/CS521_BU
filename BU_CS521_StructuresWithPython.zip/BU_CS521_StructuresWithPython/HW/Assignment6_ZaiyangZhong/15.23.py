"""(Page 428 - 430): 12.2, 12.3
(Page 523 - 525): 15.1, 15.3, 15.23
"""

"""15.23
(String permutation) 
Write a recursive function to print all the permutations of a
string. For example, for the string abc, the printout is:
          abc
          acb
          bac
          bca
          cab
          cba
(Hint: Define the following two functions. The second function is a helper function.
def displayPermuation(s):
def displayPermuationHelper(s1, s2):
Programming Exercises 525
 526 Chapter 15
Recursion
    (a) (b) (c) (d)
FIGURE 15.14
The first function simply invokes displayPermuation(" ", s).
 The second function uses a loop to move a character from s2 to s1 
 and recursively invokes it with a new s1 and s2.
  The base case is that s2 is empty and prints s1 to the console.)
Write a test program that prompts the user to 
enter a string and displays all its permutations.main()
"""


# recursive
def displayPermutation(s):
    return displayPermutationHelper("", s)



#return a set of all permutations on the string
def displayPermutationHelper(s1,s2):

    # base case
    if len(s2) <= 1:
        return set([s2])


    all_permutations = []

    for i in range(len(s2)):
        first = s2[i] # letter to replace
        rest = s2[:i] + s2[i+1:] # the rest of string
        permutations = displayPermutationHelper(first,rest)

        for p in permutations:
            all_permutations.append(first + p)

    return set(all_permutations)


def driver():
    string = input("Enter a string to see its permutation: ")

    set = displayPermutation(string)

    # print all
    for each in set:
        print(each)


driver()