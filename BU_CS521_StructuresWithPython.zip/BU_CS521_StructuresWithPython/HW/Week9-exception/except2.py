from random import randrange

def func1():
    if randrange(0, 3) == 0:
        raise FileNotFoundError
    return 1

def func2():
    if randrange(0, 3) == 0:
        raise PermissionError
    return 2

def func3():
    if randrange(0, 3) == 0:
        raise OSError("Invalid")
    return 3

try:
    val1 = val2 = val3 = 0
    val1 = func1()
    val2 = func2()
    val3 = func3()

except FileNotFoundError:
    print("Cannot find file")

except PermissionError:
    print("Cannot access")

except OSError as e:
    print(e)
    raise e

else:
    print("ELS: ", val1, ", ", val2, ", ", val3)

finally:
    print("FIN: ", val1, ", ", val2, ", ", val3)  
