# demo of module

def isPrime(n):
    for x in range(2, n):
        if n % x == 0:
            break
    else:
        return True

    return False

def test_isPrime():
    for i in range(2, 100):
        if isPrime(i):
            print(i)

if __name__ == '__main__':
    test_isPrime()

