''' Demo for iterable and iterator
    We are required to list all books on bookshelf, and then
    list all books again sorted by price in descending order.
    This code does not work, because Bookshelf is not iterable
'''

class Bookshelf:
    def __init__(self):
        self.__book_list = []

    def addBook(self, author, title, price):
        self.__book_list.append((author, title, price))

myshelf = Bookshelf()
myshelf.addBook("Jane Austen", "Pride and Prejudice", 6.95)
myshelf.addBook("William Shakespeare", "Romeo and Juliet", 10.99)
myshelf.addBook("Mark Twain", "Adventures of Huckleberry Finn", 5.95)
myshelf.addBook("Fyodor Destoevsky", "Crime and Punishment", 12.95)
myshelf.addBook("Leo Tolstoy", "Anna Karenina", 9.56)
myshelf.addBook("William Shakespeare", "Macbeth", 5.99)
myshelf.addBook("Leo Tolstoy", "War and Peace", 10.36)

# List all books on bookshelf
for b in myshelf:
    print(b)

print()

# list all books again sorted by price in descending order
for b in sorted(myshelf, key=lambda x : x[2], reverse=True):
    print(b)
