def fib_l(n):
  a, b = 1, 1
  for i in range(n-1):
    a, b = b, a + b
    
  return a

def fib_r(n):
  if n==1 or n==2:
    return 1
    
  return fib_r(n-1) + fib_r(n-2)

#import sys
  
#if __name__ == '__main__':
#  print("Looping:", fib_l(int(sys.argv[1])))
#  print("Recursion:", fib_r(int(sys.argv[1])))

#fib_r(10)
