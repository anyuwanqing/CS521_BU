class TreeNode:
    def __init__(self, name):
        self.name = name
        self.parent = None
        self.children = []

    def addChild(self, child):
        self.children.append(child)
        child.parent = self

    def printPreOrder(self):
        # print the node itself first
        print(self.name, end=',')

        # print each of its children in pre-order
        if len(self.children):
            for child in self.children:
                child.printPreOrder()

    def printPostOrder(self):
        # print each of its children in post-order
        if len(self.children):
            for child in self.children:
                child.printPostOrder()

        # print the node itself
        print(self.name, end=',')

def test():
    root = TreeNode('F')
    a_node = TreeNode('A')
    b_node = TreeNode('B')
    c_node = TreeNode('C')
    d_node = TreeNode('D')
    e_node = TreeNode('E')
    f_node = TreeNode('F')
    g_node = TreeNode('G')
    h_node = TreeNode('H')
    i_node = TreeNode('I')

    root.addChild(b_node)
    root.addChild(g_node)

    b_node.addChild(a_node)
    b_node.addChild(d_node)

    d_node.addChild(c_node)
    d_node.addChild(e_node)

    g_node.addChild(i_node)
    i_node.addChild(h_node)

    print('Pre-order: ', end='')
    root.printPreOrder()
    print()

    print('Post-order: ', end='')
    root.printPostOrder()
    print()
    
