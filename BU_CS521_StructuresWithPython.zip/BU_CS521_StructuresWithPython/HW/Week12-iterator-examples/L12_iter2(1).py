''' Demo for iterable and iterator
    Bookshelf is both an iterable and an iterator.
'''

class Bookshelf:
    def __init__(self):
        self.__book_list = []
        self.next_index = -1

    def addBook(self, author, title, price):
        self.__book_list.append((author, title, price))

    def __iter__(self):
        return self

    def __next__(self):
        self.next_index += 1
        if self.next_index >= len(self.__book_list):
            raise StopIteration
        return self.__book_list[self.next_index]

myshelf = Bookshelf()
myshelf.addBook("Jane Austen", "Pride and Prejudice", 6.95)
myshelf.addBook("William Shakespeare", "Romeo and Juliet", 10.99)
myshelf.addBook("Mark Twain", "Adventures of Huckleberry Finn", 5.95)
myshelf.addBook("Fyodor Destoevsky", "Crime and Punishment", 12.95)
myshelf.addBook("Leo Tolstoy", "Anna Karenina", 9.56)
myshelf.addBook("William Shakespeare", "Macbeth", 5.99)
myshelf.addBook("Leo Tolstoy", "War and Peace", 10.36)

print("--- Listing all books ---")
for b in myshelf:
    print(b)

print()

print("--- Listing books by price ---")
for b in sorted(myshelf, key=lambda x : x[2], reverse=True):
    print(b)

#####
# Explain why calling next(myshelf) now cause StopIteration
# The __iter__ returns self, instead of an iterator of the list
