''' Demo for iterable and iterator
    We are required to list all books on bookshelf, and then
    list all books again sorted by price in descending order.
    This code exposes the internal list of Bookshelf
'''

class Bookshelf:
    def __init__(self):
        self.__book_list = []

    def addBook(self, author, title, price):
        self.__book_list.append((author, title, price))

    def listBooks(self):
        return self.__book_list

myshelf = Bookshelf()
myshelf.addBook("Jane Austen", "Pride and Prejudice", 6.95)
myshelf.addBook("William Shakespeare", "Romeo and Juliet", 10.99)
myshelf.addBook("Mark Twain", "Adventures of Huckleberry Finn", 5.95)
myshelf.addBook("Fyodor Destoevsky", "Crime and Punishment", 12.95)
myshelf.addBook("Leo Tolstoy", "Anna Karenina", 9.56)
myshelf.addBook("William Shakespeare", "Macbeth", 5.99)
myshelf.addBook("Leo Tolstoy", "War and Peace", 10.36)

#for b in myshelf:
#    print(b)

for b in myshelf.listBooks():
    print(b)

print()

for b in sorted(myshelf.listBooks(), key=lambda x : x[2], reverse=True):
    print(b)

#####
#l = myshelf.listBooks()
#l.append("football")
#
#        return self.__book_list.copy()
