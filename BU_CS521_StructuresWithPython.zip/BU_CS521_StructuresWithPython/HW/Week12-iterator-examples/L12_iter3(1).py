''' Demo for iterable and iterator
    The itrator is separated from Bookshelf.
'''

class Bookshelf:
    def __init__(self):
        self.__book_list = []

    def addBook(self, author, title, price):
        self.__book_list.append((author, title, price))

class BookIter:
    def __init__(self, bookshelf):
        self.reflist = [b for b in bookshelf._Bookshelf__book_list]

    def __iter__(self):
        return self

    def __next__(self):
        raise StopIteration
    
class BookAuthorIter(BookIter):
    def __iter__(self):
        return iter(sorted(self.reflist, key=lambda x:x[0]))

# dictionary for lookingup country of the author
author_country = {"Jane Austen" : "UK", "William Shakespeare" : "UK", \
                  "Mark Twain" : "US", "Leo Tolstoy" : "Russia", \
                  "Fyodor Destoevsky" : "Russia"}
    
class BookCountryIter(BookIter):
    def __init__(self, bookshelf):
        super().__init__(bookshelf)
        self.book_iter = \
            iter(sorted([(b, author_country[b[0]]) for b in self.reflist],
                        key=lambda x : x[1]))
        #books_with_country = [(b, author_country[b[0]]) for b in self.reflist]
        #books_sort_country = sorted(books_with_country, key=lambda x : x[1])
        #self.book_iter = iter(books_sort_country)

    def __next__(self):
        return next(self.book_iter)[0]
        

myshelf = Bookshelf()
myshelf.addBook("Jane Austen", "Pride and Prejudice", 6.95)
myshelf.addBook("William Shakespeare", "Romeo and Juliet", 10.99)
myshelf.addBook("Mark Twain", "Adventures of Huckleberry Finn", 5.95)
myshelf.addBook("Fyodor Destoevsky", "Crime and Punishment", 12.95)
myshelf.addBook("Leo Tolstoy", "Anna Karenina", 9.56)
myshelf.addBook("William Shakespeare", "Macbeth", 5.99)
myshelf.addBook("Leo Tolstoy", "War and Peace", 10.36)

print("--- Listing books by author ---")
for b in BookAuthorIter(myshelf):
    print(b)

print()

print("--- Listing books by country ---")
for b in BookCountryIter(myshelf):
    print(b)

