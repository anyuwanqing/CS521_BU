#!/usr/bin/env python3

def toh(n, origin, target, interim):
  if n < 1:
    raise Exception('invalid input')
    
  if n == 1:
    print('Move Disc', n, 'from Pole', origin, 'to Pole', target)
    return
  
  toh(n-1, origin, interim, target)
  print('Move Disc', n, 'from Pole', origin, 'to Pole', target)
  toh(n-1, interim, target, origin)
  
  return


#import sys
  
#if __name__ == '__main__':
#  toh(int(sys.argv[1]), 0, 1, 2)
