""""(Financial: credit card number validation)
Credit card numbers follow certain patterns:
It must have between 13 and 16 digits, and the number must start with:
    ■ 4 for Visa cards
    ■ 5 for MasterCard credit cards
■ 37 for American Express cards
■ 6 for Discover cards
    In 1954, Hans Luhn of IBM proposed an algorithm
    for validating credit card num- bers.
    The algorithm is useful to determine whether a card number
     is entered cor- rectly or whether a credit card
     is scanned correctly by a scanner. Credit card numbers
      are generated following this validity check, commonly
      known as the Luhn check or the Mod 10 check, which can be
      described as follows (for illustra- tion, consider
      the card number 4388576018402626):"""

# Return sum of odd place digits in number
def sumOfOddPlace(number):
    #4388576018402626   -> 6+6+....

    sum = 0

    # convert to string, then int, seperate number
    num_list = [int(d) for d in str(number)]

    # if even, take even index:  439989 -> 3 9 9
    if (len(num_list) % 2) == 0:
        for i in range(1, len(num_list), 2):
            sum += num_list[i]
        return sum

    # if odd, take odd index: 43998 -> 4 9 8...
    else:
        for i in range(0, len(num_list), 2):
            sum += num_list[i]
        return sum



#return a list of single digit number
def getDigit(num):

    # convert to string, then int, seperate number
    num_list = [int(d) for d in str(num)]
    digit_list = []

    # if even, take even index:  439989 -> take 4 9 8
    if (len(num_list) % 2) == 0:
        for i in range(0, len(num_list), 2):
            digit_list.append(num_list[i])
        return digit_list

    # if odd, take even index: 43998 -> take 3 9
    else:
        for i in range(1, len(num_list), 2):
            digit_list.append(num_list[i])
        return digit_list



def helperGetSingleDigit(num):
    # if 18, makes it 1+8 = 9
    num_list = [int(d) for d in str(num)]
    return (num_list[0] + num_list[1])

# Get the result from Step 2
# if doubling results in a two digit number, add the digits of product
def sumOfDoubleEvenPlace(number):
    digit_list = getDigit(number)
    sum = 0

    for each in digit_list:
        double = 2*each
        if double > 9:
            double = helperGetSingleDigit(double)
        sum = sum + double

    print(" sum of doublings: " + str(sum))
    return sum

# Return true if the card number is valid
def isValid(number):
    valid = False

    sumDouble_SecondDigit = sumOfDoubleEvenPlace(number)
    sumSingle = sumOfOddPlace(number)
    print(" sum of singles: " + str(sumSingle))

    if ((sumDouble_SecondDigit + sumSingle) % 10) == 0:
        valid = True
        print("number " + str(number) + " is valid creadit card number.")
    else:
        print("number " + str(number) + " is NOT valid creadit card number.")
    return valid

def main():
    card = input("Enter card number:")
    isValid(card)

main()





