
"""(Emirp) An emirp ( prime spelled backward) is
 a nonpalindromic prime number whose reversal
 is also a prime. For example, both 17 and 71 are prime numbers,
  so 17 and 71 are emirps. Write a program that displays the first 100 emirps.
   Display 10 numbers per line and align the numbers properly, as follows:"""

def isPrime(num):

    prime = True

    if num > 1:
        # check factor from 2 to num
        for i in range(2,num):
            if (num % i) == 0: # remainer ever equals zero, return false
                prime = False
                return prime
    else:
        return False

    return prime


def reversenum(num):

    reverse_num = 0

    while num != 0:
        digit = num % 10
        reverse_num *= 10
        reverse_num += digit
        num //= 10
    return reverse_num

def isEmirp(num):

    # if it's bigger than 10, and after reverse it doesn't equal itself

    if isPrime(num):
        if reversenum(num) >= 10 and num >= 10 and reversenum(num) != num:
            return isPrime(reversenum(num))
        else:
            return False
    else:
        return False


def printListStr(list):
    strings = [str(x) for x in list]
    print(" ".join(strings))


def displayEimrp():
    eimrplist = []

    reset = 0


    for num in range(1, 10000):
        if isEmirp(num):
            eimrplist.append(num)

    displayTen = []
    count = 0
    for each in range(0, len(eimrplist)):
        # reset 9 times, which means it runs 100 numbers, stop program
        if reset == 10:
            break;
        else:
            if count < 10:
                displayTen.append(eimrplist[each])
                count += 1
            elif count == 10:
                # reset count and display array
                count = 0
                printListStr(displayTen)
                displayTen = []
                reset += 1


displayEimrp()



