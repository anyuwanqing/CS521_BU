
"""14.10

(Guess the capitals) Rewrite Exercise 11.40
using a dictionary to store the pairs of states
and capitals so that the questions
 are randomly displayed."""

import random

# convert the 2D list to dict
Capitals = [
    ["Afghanistan","Kabul"],
    ["Albania","Tirana"],
    ["Belgium","Brussels"],
    ["Brazil","Brasilia"],
    ["Canada","Ottawa"],
    ["China","Beijing"],
    ["Denmark","Copenhagen"],
    ["Dominica","Roseau"],
    ["Egypt","Cairo"],
    ["England","London"],
    ["Finland","Helsinki"],
    ["France","Paris"],
    ["Germany","Berlin"],
    ["Ghana","Accra"],
    ["Haiti","Port au Prince"],
    ["Iceland","Reykjavik"],
    ["India","New Delhi"],
    ["Indonesia","Jakarta"],
    ["Iraq","Baghdad"],
    ["Isreal","Jerusalem"],
    ["Italy","Rome"],
    ["Japan","Tokyo"],
    ["Kosovo","Pristina"],
    ["Liberia","Monrovia"],
    ["Liechtenstein","Vaduz"],
    ["Malawi","Lilongwe"],
    ["Mexico","Mexico City"],
    ["Netherlands","Amsterdam"],
    ["New Zealand","Wellington"],
    ["North Korea","Pyongyang"],
    ["Norway","Oslo"],
    ["Peru","Lima"],
    ["Poland","Warsaw"],
    ["Romania","Bucharest"],
    ["Samoa","Apia"],
    ["Serbia","Belgrade"],
    ["Somalia","Mogadishu"],
    ["South Korea","Seoul"],
    ["Switzerland","Bern"],
    ["Taiwan","Taipei"],
    ["Togo","Lome"],
    ["Tonga","Nuku'alofa"],
    ["Uganda","Kampala"],
    ["Ukraine","Kyiv or Kiev"],
    ["UK","London"],
    ["Vatican City","Vatican City"],
    ["Wales","Hanoi"],
    ["Yemen","Sana'a"]
]



correct = 0
total = 0
again = 1



# 2D array convert to dict
d = {}
for elem in Capitals:
    if elem[1] in d:
        d[elem[1]].append(elem[0])
    else:
        d[elem[1]] = [elem[0]]

# now dict is the dictionary

while again:
    val = random.choice(list(d.keys()))
    country = d.get(val)

    c = input("What's capital of " + str(country) + " ?")
    total += 1

    if c.lower() == "".join(val).lower():
        print("correct answer.")
        correct += 1
    else:
        print("incorrect. correct is " + "".join(val))

    again = (input("play again? y or n") == 'y')
