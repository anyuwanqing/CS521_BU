"""(Display nonduplicate words in
ascending order) Write a program that prompts
the user to enter a text file, reads words from the file,
 and displays all the nondu- plicate words in ascending order."""


def main():
    try:
        filename = input("Enter the textfile name: (e.g. 'text_file.txt') ")
        file = open(filename,"r")

        words = file.read()
        s = set()
        items = words.split()

        # non dup, then sorted, then print out every word on ascending order
        non_dup = set(str(x) for x in items)
        sorted_non_dup = sorted(non_dup)

        for word in sorted_non_dup:
            print(word, end=' ')

        file.close()
    except:
        print("error open file")

main()

