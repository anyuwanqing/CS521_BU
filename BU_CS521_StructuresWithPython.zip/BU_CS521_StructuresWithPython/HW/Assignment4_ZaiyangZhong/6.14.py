#6.14, 6.25, 6.29

""""(Estimate p) p can be computed
 using the following series:
Write a function that returns m(i)
for a given i and write a test program that dis-
plays the following table:"""




def pie(i):

    total = 1

    if i == 1:
        return 4
    else:

        start = 3


        minus = True

        # like a switch on and off for minus and add
        while start <= (2*i - 1):

            # now, start is 3
            if minus:
                total += ((-1)* (1/ start))
                minus = False
            else:
                minus = True
                total +=  (1/ start)

            start += 2 # accumulate

    return 4 * total

# display table
def table():
    print("i        m(i)")

    i = 1
    while i <= 901:
        print(str(i) + "        " +  str(round(pie(i), 4)))
        i += 100

table()



