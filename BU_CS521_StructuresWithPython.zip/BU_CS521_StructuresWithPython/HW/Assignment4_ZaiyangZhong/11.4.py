#(Page 395): 11.40
#(Page 497): 14.8, 14.10
#(Page 206 - 211): 6.14, 6.25, 6.29
import random

"""11.4"""

""""(Guess the capitals) Write a program that
repeatedly prompts the user to enter a capital
for a state. Upon receiving the user input,
the program reports whether the answer is correct.
Assume that 50 states and their capitals are stored
in a two- dimensional list, as shown in Figure 11.13.
 The program prompts the user to answer all the states’
  capitals and displays the total correct count.
  The user’s answer is not case sensitive.
  Implement the program using a list to
  represent the data in the following table.
"""

def main():
    Capitals = [
        ["Afghanistan","Kabul"],
        ["Albania","Tirana"],
        ["Belgium","Brussels"],
        ["Brazil","Brasilia"],
        ["Canada","Ottawa"],
        ["China","Beijing"],
        ["Denmark","Copenhagen"],
        ["Dominica","Roseau"],
        ["Egypt","Cairo"],
        ["England","London"],
        ["Finland","Helsinki"],
        ["France","Paris"],
        ["Germany","Berlin"],
        ["Ghana","Accra"],
        ["Haiti","Port au Prince"],
        ["Iceland","Reykjavik"],
        ["India","New Delhi"],
        ["Indonesia","Jakarta"],
        ["Iraq","Baghdad"],
        ["Isreal","Jerusalem"],
        ["Italy","Rome"],
        ["Japan","Tokyo"],
        ["Kosovo","Pristina"],
        ["Liberia","Monrovia"],
        ["Liechtenstein","Vaduz"],
        ["Malawi","Lilongwe"],
        ["Mexico","Mexico City"],
        ["Netherlands","Amsterdam"],
        ["New Zealand","Wellington"],
        ["North Korea","Pyongyang"],
        ["Norway","Oslo"],
        ["Peru","Lima"],
        ["Poland","Warsaw"],
        ["Romania","Bucharest"],
        ["Samoa","Apia"],
        ["Serbia","Belgrade"],
        ["Somalia","Mogadishu"],
        ["South Korea","Seoul"],
        ["Switzerland","Bern"],
        ["Taiwan","Taipei"],
        ["Togo","Lome"],
        ["Tonga","Nuku'alofa"],
        ["Uganda","Kampala"],
        ["Ukraine","Kyiv or Kiev"],
        ["UK","London"],
        ["Vatican City","Vatican City"],
        ["Wales","Hanoi"],
        ["Yemen","Sana'a"]
    ]

    correct_answer = 0


    for i in range(len(Capitals)):

        country_name = Capitals[i][0]

        answer = input("What is the capital of  " + country_name + "?")
        if answer.lower() == Capitals[i][1].lower():
            correct_answer += 1
            print("Your answer's correct")

        else:
            print("The correct answer is " + Capitals[i][1])
    print("Total correct answer is: " + str(correct_answer))


main()

