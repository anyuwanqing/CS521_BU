x = 'Boston'
y = x[0]
print(x is y)

x = {'Boston', 'Boston'}
y = {'Boston', 'Boston'}
print(x is y)


x = ['Boston', 'Boston']
y = x
print(x is y)

x = 'Boston'
print("Welcome to CS521"[-3])

print(round(math.pi, 3))
print(format(math.pi, '6.3f'))