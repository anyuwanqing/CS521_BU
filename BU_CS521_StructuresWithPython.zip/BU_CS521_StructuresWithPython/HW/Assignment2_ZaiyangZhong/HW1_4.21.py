

#4.21

import math

"""
(Science: day of the week) Zeller’s congruence is an 
algorithm developed by Christian Zeller 
to calculate the day of the week. The formula is
h = ¢q + j26(m + 1)k + k + jkk + jjk + 5j≤%7 10 44
where

■ h is the day of the week (0: Saturday, 1: Sunday, 2: Monday, 3: Tuesday, 4: Wednesday, 5: Thursday, 6: Friday).
■ q is the day of the month.
■ m is the month (3:March,4:April,...,12:December).January and February are
counted as months 13 and 14 of the previous year.
year
■ j is the century (i.e.,j 100 k).
■ k is the year of the century(i.e.,year%100).
Write a program that prompts the user to enter a year, month, and day of the month, and then it displays the name of the day of the week. Here are some sam- ple runs:
"""


input_year = eval(input("Enter year:"))
input_month = eval(input("Enter month: 1-12:"))
input_day = eval(input("Enter the day of the month: 1-31:"))


q = input_day
# handle month
if input_month > 2:
    m = input_month
    j = math.floor(input_year // 100) #2022/100 = 202.2  -> 202
    k = input_year % 100


else:
    # counted as previous year, so year much be 1 less
    input_year -= 1

    m = input_month + 12
    j = math.floor(input_year // 100) #2022/100 = 202.2  -> 202
    k = input_year % 100


# use formula
h = (q + math.floor((26 * (m + 1)) / 10) + k + math.floor(k / 4)
     + math.floor(j / 4) + 5 * j) % 7

return_day = {
    0 : "Saturday",
    1 : "Sunday",
    2 : "Monday",
    3 : "Tuesday",
    4 : "Wednesday",
    5 : "Thursday",
    6 : "Friday"
}

day = return_day[h]

print("Day of the week is: ", day)


