
# 4.34

"""(Hex to decimal) Write a program that prompts the user
to enter a hex character and displays its
corresponding decimal integer.
Here are some sample runs
"""

import math

hex_value = input("Enter a hex value (0 to 10 and A to F):  ")


if len(hex_value) != 1 or ord(hex_value) > ord('F') and ord(hex_value) < ord('a') or ord(hex_value) > ord('f'):
    print("Invalid input")
else:
    if hex_value == 'a' or hex_value == 'A':
        print("10")
    elif hex_value == 'b' or hex_value == 'B':
        print("11")
    elif hex_value == 'c' or hex_value == 'C':
        print("12")
    elif hex_value == 'd' or hex_value == 'D':
        print("13")
    elif hex_value == 'e' or hex_value == 'E':
        print("14")
    elif hex_value == 'f' or hex_value == 'F':
        print("15")
    else:
        print(hex_value)

