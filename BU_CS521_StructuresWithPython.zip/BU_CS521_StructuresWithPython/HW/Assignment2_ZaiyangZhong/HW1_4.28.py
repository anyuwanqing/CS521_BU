
# 4.28

"""(Geometry: two rectangles)
 Write a program that prompts the user to enter
  the center x-, y-coordinates, width, and
  height of two rectangles and determines whether
  the second rectangle is inside the first or overlaps with the first,
  as shown in Figure 4.10. Test your program to cover all cases.
  """

import math
rec_x1, rec_y1, rec_w1, rec_h1 = eval(input("Enter r1's center x-, y-coordinates, width and height:"))
rec_x2, rec_y2, rec_w2, rec_h2 = eval(input("Enter r2's center x-, y-coordinates, width and height:"))


#calculate the points of the rectangle
right1 = rec_x1 + rec_w1/2
left1 = rec_x1 - rec_w1/2
top1 = rec_x1 + rec_h1/2
bottom1 = rec_x1 - rec_h1/2

right2 = rec_x2 + rec_w2/2
left2 = rec_x2 - rec_w2/2
top2 = rec_x2 + rec_h2/2
bottom2 = rec_x2 - rec_h2/2


if right2 <= right1 and left2 >= left1 and top2 <= top1 and bottom2 >= bottom1:
    print("r2 is inside r1")
elif right2 <= left1 or left2 >= right1 or bottom2 >= top1 or top2 <=bottom1:
    print("r2 does not overlap r1")
else:
    print("r2 overlaps r1")



