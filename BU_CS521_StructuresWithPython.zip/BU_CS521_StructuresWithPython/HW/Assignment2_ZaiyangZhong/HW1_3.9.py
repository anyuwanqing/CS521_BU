# Assignment1 _ Zaiyang Zhong
# Python 3.10


# Programming Exercises

# Page 86 - 87): 3.3, 3.9;

# (Page 125 - 130): 4.21, 4.28, 4.33, 4.34



#3.9
"""(Financial application: payroll)
Write a program that reads the following information and prints a payroll statement:
Employee’s name (e.g., Smith)
Number of hours worked in a week (e.g., 10) Hourly pay rate (e.g., 9.75)
Federal tax withholding rate (e.g., 20%) State tax withholding rate (e.g., 9%)"""


class Employee:

    def __init__(self, name, hrs_week, hrs_pay):

        self.name = name
        self.hrs_week = hrs_week
        self.hrs_pay = hrs_pay

        self.week_pay = self.hrs_week * self.hrs_pay
        self.deduction_federal = self.week_pay * FEDERAL_TAX_RATE
        self.deduction_state = self.week_pay * STATE_TAX_RATE
        self.deduction = self.deduction_federal + self.deduction_state

        self.net_pay = self.week_pay - self.deduction


new_name = input("Enter employee's name:")
new_hrs_week = eval(input("Enter number of hours worked in a week:"))
new_hrs_pay = eval(input("Enter hourly pay rate:"))
FEDERAL_TAX_RATE = eval(input("Enter federal tax withholding rate (eg. 0.2):"))
STATE_TAX_RATE = eval(input("Enter state tax withholding rate (eg. 0.09:"))

Employee1 = Employee(new_name, new_hrs_week, new_hrs_pay)

print("Emloyee's name: ", new_name)
print("Hours worked: ", new_hrs_week)
print("Pay Rate: ", new_hrs_pay)
print("Gross Pay: " , Employee1.week_pay)
print("Deductions:\n", "   Federal Withholding (", FEDERAL_TAX_RATE, 100*FEDERAL_TAX_RATE, "%): ", round(Employee1.deduction_federal, 2))
print("   State Withholding (", STATE_TAX_RATE, 100*STATE_TAX_RATE, "%): ", round(Employee1.deduction_state,2))
print("   Total Deduction: ", round(Employee1.deduction,2))
print("Net Pay: ", round(Employee1.net_pay,2))



