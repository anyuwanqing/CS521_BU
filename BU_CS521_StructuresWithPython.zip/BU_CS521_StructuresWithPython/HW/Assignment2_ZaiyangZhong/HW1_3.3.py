# Assignment1 _ Zaiyang Zhong
# Python 3.10


# Programming Exercises

# Page 86 - 87): 3.3, 3.9;

# (Page 125 - 130): 4.21, 4.28, 4.33, 4.34



# 3.3
""" (Geography: estimate areas) Find the GPS locations for Atlanta, Georgia;
 Orlando, Florida; Savannah, Georgia;
 and Charlotte, North Carolina from www.gps-data-team.com/map/
 and compute the estimated area enclosed by these four cities.
  (Hint: Use the formula in Programming Exercise 3.2
  to compute the distance between two cities.
  Divide the polygon into two triangles and use the formula
  in Programming Exercise 2.14 to compute the area of a triangle.)
"""

"""
formula 1:
d = radius * arc cos(sin(x1) * sin(x2) + cos(x1) * cos(x2) * cos(y1 - y2))
"""

"""
formula 2 for triangle:
s = (side1 + side2 + side3)/2
area = sqrt(s(s - side1) * (s - side2) * (s- side3))
"""

import math

# city coordinates [latitude, longitude]
atlanta = [33.7490, -84.3880]
orlando = [28.5384, -81.3789]
savannah = [32.0809, -81.0912]
charlotte = [35.2271, -80.8431]

# all coordinates in x,y
x1 = math.radians(atlanta[0])
y1 = math.radians(atlanta[1])

x2 = math.radians(orlando[0])
y2 = math.radians(orlando[1])

x3 = math.radians(savannah[0])
y3 = math.radians(savannah[1])

x4 = math.radians(charlotte[0])
y4 = math.radians(charlotte[1])



EARTH_RADIUS = 6371.01 # which is fixed, in KM

# compute sides
side1 = EARTH_RADIUS * math.acos(math.sin(x1) * math.sin(x2) + math.cos(x1) * math.cos(x2) * math.cos(y1 - y2))
side2 = EARTH_RADIUS * math.acos(math.sin(x2) * math.sin(x3) + math.cos(x2) * math.cos(x3) * math.cos(y2 - y3))
side3 = EARTH_RADIUS * math.acos(math.sin(x3) * math.sin(x1) + math.cos(x3) * math.cos(x1) * math.cos(y3 - y1))
side4 = EARTH_RADIUS * math.acos(math.sin(x4) * math.sin(x1) + math.cos(x4) * math.cos(x1) * math.cos(y1 - y4))
side5 = EARTH_RADIUS * math.acos(math.sin(x4) * math.sin(x3) + math.cos(x4) * math.cos(x3) * math.cos(y4 - y3))


# compute s1
s1 = (side1 + side2 + side3) / 2
# Compute the area
area1 = math.sqrt(s1 * (s1 - side1) * (s1 - side2) * (s1 - side3))
# Compute s2
s2 = (side3 + side4 + side5) / 2
# Compute the area
area2 = math.sqrt(s2 * (s2 - side3) * (s2 - side4) * (s2 - side5))

area = area1 + area2  # the polygon hole area

# Display the result
print("The estimated area enclosed by these four cities --Atlanta, Orlando, Savannah, Charlotte-- is:", area, " square km")





