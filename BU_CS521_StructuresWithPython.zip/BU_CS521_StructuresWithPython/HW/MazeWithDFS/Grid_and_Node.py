
class Grid:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def __repr__(self):
        return f'Grid(x={self.x}, y={self.y})'

class Node:
    def __init__(self, pos: Grid, value, cost):
        self.pos = pos
        self.value = value
        self.__cost = cost
    def __repr__(self):
        return f'Node(value={self.value}, cost={self.__cost}, pos={self.pos})'


    def getCost(self):
        return self.__cost

    def getPos(self):
        return self.pos

    def getValue(self):
        return self.value

    def setPos(self, pos: Grid):
        self.pos = pos

    def setWeight(self, weights):
        self.__weights = weights

    def setValue(self, v):
        self.value = v

    def __changeWeights(self, weights):
        self.setWeights(self, weights)
