from Grid_and_Node import Grid
from Grid_and_Node import Node

# up down left right
graph = {
    'A' : ['', 'D', '', 'B'],
    'B' : ['', '', 'A', 'C'],
    'C' : ['', 'F', 'B', ''],
    'D' : ['A', 'G', '', ''],
    'E' : ['', 'H', '', 'F'],
    'F' : ['C', 'I', 'E', ''],
    'G' : ['D', '', '', ''],
    'H' : ['E', '', '', ''],
    'I' : ['F', '', '', '']
}


class MazeGenerationException:
    pass

visited = set() # Set to keep track of visited nodes.

path = []

def dfs(visited, graph, start_node, end_node):

    if start_node not in visited:
        print('\nVisited node',start_node, '. Cost =', findNodeBasedOnValue(start_node).getCost(), end='')
        path.append(start_node)

        if start_node == end_node:
            print('Path found!!')
            return path

        visited.add(start_node)
        for neighbour in graph[start_node]:
            if neighbour != '':
                dfs(visited, graph, neighbour, end_node)

    return path

def initialize3x3Maze(row, node):

    try:
        for y in range(row):
            for i in range(row):
                print(' ———— ',end='')
            print('\n',end='')

            for x in range(row):
                print('| ', 0 ,' ' ,end='')
            print('|\n',end='')
        for i in range(row):
            print(' ———— ',end='')
    except:
        raise MazeGenerationException("can't generate maze")


def create3x3Maze(row, nodes):

    print('\n\n')

    for i in range(row):
        print(' ———— ',end='')
    print('\n',end='')

    print('| ', 'A',' ' ,end='')
    print('  ', 'B',' ' ,end='')
    print('  ', 'C',' ' ,end='')

    print('|\n',end='')

    print('      ',end='')
    print(' ———— ',end='')
    print('      ',end='')

    print('|\n',end='')
    print('| ', 'D',' ' ,end='')
    print('| ', 'E',' ' ,end='')
    print('  ', 'F',' ' ,end='')
    print('|\n',end='')

    print('      ',end='')
    print('      ',end='')
    print('      ',end='')

    print('|\n',end='')
    print('| ', 'G',' ' ,end='')
    print('| ', 'H',' ' ,end='')
    print('| ', 'I',' ' ,end='')
    print('|\n',end='')

    for i in range(row):
        print(' ———— ',end='')





def findNodeBasedOnValue(v):
    if v == 'A':
        return NodeA
    if v == 'B':
        return NodeB
    if v == 'C':
        return NodeC
    if v == 'D':
        return NodeD
    if v == 'E':
        return NodeE
    if v == 'F':
        return NodeF
    if v == 'G':
        return NodeG
    if v == 'H':
        return NodeH
    if v == 'I':
        return NodeI

def calculateTotalCost(path):
    total = 0
    for each in path:
        total += findNodeBasedOnValue(each).getCost()

    return total

row = 3
g00 = Grid(0,0)
g01 = Grid(0,1)
g02 = Grid(0,2)
g10 = Grid(1,0)
g11 = Grid(1,1)
g12 = Grid(1,2)
g20 = Grid(2,0)
g21 = Grid(2,1)
g22 = Grid(2,2)
NodeA = Node(g02, 'A', 5)
NodeB = Node(g12, 'B', 10)
NodeC = Node(g22, 'C', 9)
NodeD = Node(g01, 'D', 16)
NodeE = Node(g11, 'E', 3)
NodeF = Node(g12, 'F', 1)
NodeG = Node(g00, 'G', 2)
NodeH = Node(g10, 'H', 8)
NodeI = Node(g20, 'I', 6)
nodes = [[NodeA.value,NodeB.value,NodeC.value],
         [NodeD.value,NodeE.value,NodeF.value],
         [NodeG.value,NodeH.value,NodeI.value]]

import sys
def main():


    print("INITIALIZE THE MAZE")
    initialize3x3Maze(3,nodes)
    print("CREATE 3x3 MAZE")
    create3x3Maze(3, nodes)
    print("ANAYLYZE SOLUTION")

    # analyzing the solution using class
    solution = dfs(visited, graph, 'A', 'H')
    print(solution , "is path")
    print("Total cost for such path is: ", calculateTotalCost(solution))

    print("\n\n\n")
    print("Write all the system logs to maze_solution.txt ...")


    sys.stdout = open("maze_output.txt", "w")

    print("INITIALIZE THE MAZE")
    initialize3x3Maze(3,nodes)

    print("\n\n\n")
    print("ALL NODES INFORMATION")
    print(NodeA.__repr__())
    print(NodeB.__repr__())
    print(NodeC.__repr__())
    print(NodeD.__repr__())
    print(NodeE.__repr__())
    print(NodeF.__repr__())
    print(NodeG.__repr__())
    print(NodeH.__repr__())
    print(NodeI.__repr__())

    print("\n\n\n")
    print("CREATE 3x3 MAZE (WITH WALLS)")
    create3x3Maze(3, nodes)

    print("\n\n\n")
    print("Using depth-first search to find solution.")

    print("\n\n\n")
    print("ANAYLYZE SOLUTION ...")

    print(dfs(visited, graph, 'A', 'H'))
    # analyzing the solution using class
    solution = dfs(visited, graph, 'A', 'H')
    print(solution , "is path")
    print("Total cost for such path is: ", calculateTotalCost(solution))

    print("Write to file maze_solution.txt ...")

    sys.stdout.close()


main()