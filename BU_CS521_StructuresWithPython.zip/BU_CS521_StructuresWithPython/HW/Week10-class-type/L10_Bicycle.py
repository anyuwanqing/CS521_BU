class Bicycle:
    """Class for all bicycles.
       it has three attributes"""
    def __init__(self, c=0, s=0, g=1):
        self.cadence = c
        self.speed = s
        self.gear = g

    def changeCadence(self, newValue):
        self.cadence = newValue

    def changeGear(self, newValue):
        self.gear = newValue

    def speedUp(self, increment):
        self.speed += increment

    def applyBrake(self, decrement):
        self.speed -= decrement

    def printStatus(self):
        print('Current cadence is', self.cadence)
        print('Current speed is', self.speed)
        print('Current gear is', self.gear)

