from random import randrange

class Dice:

    material = 'glod'
    counter = 1

    def __init__(self, sides = 6):
        self.__sides = sides
        self.__value = 1
        self.__id = self.counter
        self.inc_seq()

    def getValue(self):
        return self.__value

    def roll(self):
        self.__value = randrange(1, self.__sides + 1)

    def get_id(self):
        return self.__id

    @classmethod
    def inc_seq(cls):
        cls.counter += 1
